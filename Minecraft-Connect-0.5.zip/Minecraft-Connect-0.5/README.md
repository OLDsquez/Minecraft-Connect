# Minecraft-Connect
A plugin that bridges Minecraft with MyBB.
