2/5
=====
- Finish mybb login integration [100%]
- Add login w/ minecraft button to current login postbit [100%]
- Edit all plugin files to use $lang instead of raw text [75%?]
- Add WOL activity hook [100%], does it work though?
- Add register with minecraft?
- Login rate limiter