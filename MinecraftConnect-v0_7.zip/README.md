# Minecraft-Connect
A plugin that bridges Minecraft with MyBB.

Development Thread: http://community.mybb.com/thread-188755.html
Github: https://github.com/squez/Minecraft-Connect/